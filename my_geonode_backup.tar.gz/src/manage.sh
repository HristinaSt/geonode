. $HOME/.override_env
/usr/bin/python /usr/src/my_geonode/manage.py $@
